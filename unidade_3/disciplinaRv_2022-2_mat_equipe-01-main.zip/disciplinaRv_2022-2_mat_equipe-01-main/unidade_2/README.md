# Unidade 2

Local para postar a atividade da unidade 2.  

[Slides](Slides.pdf "Slides")  

## Anotações

### Oculus Quest 2 ou Meta Quest 2  

Por que 6DOFs  
Unidade independente dos PCs  
Bateria baixa  
Desconfortável o uso ... problemas quem usa óculus ... faz um APP para baixa visão  
CFG "normal" as vezes é bom  

### PlayStation VR Aim  

Duas mão: destro/canhoto  
Formato diferente, mas específico para "tiro" - busca por um controle universal
2017 (ano no video)  
Dependente da câmera, do HMD  

### LeapMotion  

UltraLeap  
Dúvida de relativo / absoluto  
560,00  
Capta em raster mas transforma em vetorial  
Micro  
Não funciona mais de 3.000 metros de altura  
Inicio era só para desktop .. no TCC do Julio se pensou em tratar para deixar na vertical, depois veio está opção  
