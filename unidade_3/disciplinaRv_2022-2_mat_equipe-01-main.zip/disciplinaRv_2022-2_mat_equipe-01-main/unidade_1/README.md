# Unidade 1

Local para postar a atividade da unidade 1.  

## Avaliação

### Trabalho Correlato 1

Acadêmico: Martha Lanser Bloemer  
Comentários:  

- Climb2  
- Oculus Quest 2: hardware "rico"  
  - será que daria para fazer o mesmo "entregável" com um hardware "pobre"  
- Não tem luvas, mas tem os dois atuadores  
- pode ser jogado sentado e em pé  
- Jogo em evolução  
- GamePlay
- não tem retorno de tato  

### Trabalho Correlato 2

Acadêmico: Guilherme Fibrantz  
Comentários:  

- Open Brush  
- projeto da Google descontinuado  
- comunidade pequena que tem o Oculus Quest  
- Daria para fazer usando hardware "pobre" ... trabalho de uma equipe de RV/Ped de desenho compartilhado  
- existia uma proposta de ter galeria virtuais em RA  

### Trabalho Correlato 3

Acadêmico: Julio Vicente Brych  
Inception VR  

- festas só com fones de ouvido  
- custo e possibilidades de entretedimento enormes ... favorável para "novas" mentes  
- Visualizador de situações  

<https://github.com/tecedufurb/habitat/tree/main/producao>
