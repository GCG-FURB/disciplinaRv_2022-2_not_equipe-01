using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Audio : MonoBehaviour
{
    // Start is called before the first frame update
    public AudioSource source;
    public AudioClip clip;

    // Update is called once per frame
    void Update()
    {
        
    }

    public void carregaAudio()
    {
       // source.PlayOneShot(clip);
    }

   

}
