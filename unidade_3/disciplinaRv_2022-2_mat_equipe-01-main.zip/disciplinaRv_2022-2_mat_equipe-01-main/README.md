# Realidade Virtual

Atividades desenvolvidas na disciplina de Computação Gráfica na FURB/DSC/BCC.  
Favor utilizar as respectivas pastas para postar os trabalhos de cada unidade.  

Alunos: Guilherme Fibrantz, Julio Vicente Brych e Martha Lanser Bloemer  
Assunto: Realidade Virtual Imersiva (RVi): óculos (só mundo virtual)  

## [Atividades da Unidade 1](unidade_1 "Atividades da Unidade 1")  

## [Atividades da Unidade 2](unidade_2 "Atividades da Unidade 2")  

## [Atividades da Unidade 3](unidade_3 "Atividades da Unidade 3")  

## [Atividades da Unidade 4](unidade_4 "Atividades da Unidade 4")  
